package vsu.cs.vega.logic;


public class Solution {


	public static int[][] TurnRight90(int[][] array) {
		int maxCshetchic = -1;
		int maximumPramoug = 0;
		int[][] otnvetPramoug = new int[0][];
		int[][] concurent = new int[0][];
		int S1 = 0;
		int S2;


		for (int i = 0; i < array.length; i++) {
			int[][] progonPramoug = {{array[i][0], array[i][1]}, {array[i][2], array[i][3]}};

			for (int[] ints : array) {
				int[][] poiskSamogoMalPramoug = {{ints[0], ints[1]}, {ints[2], ints[3]}};

				if (proverkaNaVmestimostOdnogoPramougolVDrugoi(progonPramoug, poiskSamogoMalPramoug)) {
					maxCshetchic++;

					concurent = new int[][]{{ints[0], ints[1], ints[2], ints[3]}};

				}
			}
			if (maxCshetchic > maximumPramoug) {
				maximumPramoug = maxCshetchic;
				otnvetPramoug = new int[][]{{array[i][0], array[i][1], array[i][2], array[i][3]}};


			}
			// эта часть кода должна сравнить периметры и выдать на с большим значением, но она почему-то не работает
//			if (maxCshetchic == maximumPramoug && maximumPramoug > 0) {
////
//				S1 = (otnvetPramoug[0][2] - otnvetPramoug[0][0]) * (otnvetPramoug[0][3] - otnvetPramoug[0][1]);
////
////
//				S2 = (concurent[0][2] - concurent[0][0]) * (concurent[0][1] - concurent[2][1]);
//
//
//				if (S2 > S1) {
//					System.out.println("ldflkdsjfksd");
////					otnvetPramoug = new int[][]{{concurent[0][0], concurent[0][1], concurent[1][0], concurent[1][1]}};
//				}
//			}

			maxCshetchic = -1;
		}return otnvetPramoug;
	}

	public static boolean proverkaNaVmestimostOdnogoPramougolVDrugoi ( int[][] smal, int[][] big){

		return smal[0][0] >= big[0][0] && smal[0][1] >= big[0][1] && smal[1][0] <= big[1][0]
				&& smal[1][1] <= big[1][1];

	}

}

